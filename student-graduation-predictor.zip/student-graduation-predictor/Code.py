import numpy as np  
import pandas as pd  
import matplotlib.pyplot as plt  
import matplotlib as mpl  
import seaborn as sns
import gspread
from google.oauth2.service_account import Credentials  
from sklearn.preprocessing import MinMaxScaler  
from sklearn.model_selection import train_test_split  
from sklearn.ensemble import HistGradientBoostingClassifier  
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_auc_score  
from sklearn.impute import SimpleImputer  
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import cross_val_score
from collections import Counter

# กำหนดการเข้าถึง Google Sheets API
scopes = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
creds = Credentials.from_service_account_file("neon-particle-455114-j2-d3f2aea64ca5.json", scopes=scopes)
client = gspread.authorize(creds)

# เปิด Google Sheets ด้วย URL หรือ Spreadsheet ID
spreadsheet = client.open_by_url("https://docs.google.com/spreadsheets/d/1B-_y_NYhc8HDo9ms3n5qivJZzULN2-tV-nDrRx5fIwk/edit?resourcekey=&gid=155480274#gid=155480274")
worksheet = spreadsheet.sheet1

#ใส่ Font ให้ดูดี
mpl.font_manager.fontManager.addfont('THSarabunNew.ttf')
mpl.rc('font', family='TH Sarabun New')

# อ่านข้อมูลทั้งหมดจาก Google Sheets
data = worksheet.get_all_values()

df = pd.DataFrame(data[1:], columns=data[0])

# 👉 แทนช่องว่างทั้งหมดด้วย np.nan และเติม 'ไม่ระบุ'
df.replace('', np.nan, inplace=True)
df.fillna('ไม่ระบุ', inplace=True)

#เปลี่ยนชื่อคอลัมน์จากภาษาไทยเป็นภาษาอังกฤษเพื่อให้เรียกใช้งานได้สะดวก
df.rename(columns={"Timestamp": "Time"}, inplace=True)
df.rename(columns={"ท่านอนุญาตให้เราเก็บข้อมูล เพื่อนำไปวิเคราห์ปัจจัยที่ส่งผลต่อระยะเวลาการจบการศึกษาตามกำหนด ของนีกศึกษา (โดยทางเราจะเก็บรักษาข้อมูลอย่างเคร่งครัด)": "Policy"}, inplace=True)
df.rename(columns={"1. เพศ": "เพศ"}, inplace=True)
df.rename(columns={"2. อายุ(กรอกเป็นตัวเลข)": "อายุ"}, inplace=True)
df.rename(columns={"3. รหัสนักศึกษา(เช่น166090xxxx)": "รหัสนักศึกษา"}, inplace=True)
df.rename(columns={"4. ปัจจุบันกำลังศึกษาชั้นที่": "ชั้นปี"}, inplace=True)
df.rename(columns={"5. คณะที่คุณกำลังศึกษาอยู่": "คณะ"}, inplace=True)
df.rename(columns={"ท่านชอบคณะที่เรียนอยู่ไหม": "ชอบ คณะ"}, inplace=True)
df.rename(columns={"เพราะอะไรถึงเลือกเรียนคณะนี้": "เหตุผล คณะ"}, inplace=True)
df.rename(columns={"6.  ท่านยังลงเรียนตาม Degree Plan ของมหาวิทยาลัยหรือไม่": "ลงตาม Degree"}, inplace=True)
df.rename(columns={"7. คุณดู Degree Plan เป็นหรือไม่": "ดู Degree"}, inplace=True)
df.rename(columns={"8. เกรดเฉลี่ยสะสม (GPAX) ถึงปัจจุบัน": "GPAX"}, inplace=True)
df.rename(columns={"1. คุณวางแผนจบการศึกษาภายในระยะเวลาที่หลักสูตรกำหนดหรือไม่": "จบตามแผน"}, inplace=True)
df.rename(columns={"2. หากไม่สามารถจบการศึกษาได้ตามกำหนด คุณสาเหตุหลักคืออะไร (ตอบได้มากกว่า 1 ข้อ)": "เหตุผล"}, inplace=True)
df.rename(columns={"3.คุณเคยเพิกถอนวิชาเรียนไหม": "ถอน"}, inplace=True)
df.rename(columns={"4.  คุณเคยเพิกถอนวิชาเรียนกี่ตัว (นับตั้งแต่เทอมแรกที่เข้าศึกษา)": "ถอนกี่ตัว"}, inplace=True)
df.rename(columns={"5. คุณเคยพักการเรียนไหม": "พักการเรียน"}, inplace=True)
df.rename(columns={"6. คุณเข้าชั้นเรียนบ่อยหรือไม่": "เข้าเรียน"}, inplace=True)
df.rename(columns={"7. คุณมีวินัยการส่งงานแค่ไหน": "ส่งงาน"}, inplace=True)
df.rename(columns={"8. คุณเคยหยุดการเรียนชั่วคราวนานเท่าไหร่ (ต่อเทอม)": "หยุดเรียน"}, inplace=True)
df.rename(columns={"9. คุณเคยได้ F และต้องลงทะเบียนเรียนซ้ำหรือไม่": "F"}, inplace=True)
df.rename(columns={"1. ครอบครัวคุณซับพอร์ตค่าเทอมให้คุณหรือไม่": "ซัพพอร์ต"}, inplace=True)
df.rename(columns={"2.คุณได้ขอทุนการศึกษาหรือไม่ (เช่น กยศ , กรอ , ทุนมหาลัย )": "ทุน"}, inplace=True)
df.rename(columns={"3.คุณได้ขอค่าครองชีพหรือไม่": "ค่าครอบชีพ"}, inplace=True)
df.rename(columns={"4. คุณมีรายได้ต่อเดือนเท่าไหร่": "รายได้"}, inplace=True)
df.rename(columns={"5. รายจ่ายต่อเดือน": "รายจ่าย"}, inplace=True)
df.rename(columns={"6. คุณทำงานพาร์ทไทม์ หรือ งานประจำอยู่หรือไม่": "พาร์ทไทม์"}, inplace=True)
df.rename(columns={"7. งานของคุณตรงกับเวลาเรียนหรือไม่": "เวลางาน"}, inplace=True)
df.rename(columns={"8. คุณต้องทำงานเพื่อช่วยแบ่งเบาภาระครอบครัวหรือไม่  ": "ครอบครัว"}, inplace=True)
df.rename(columns={"9. คุณคิดว่าปัญหาเรื่องครอบครัว จะมีผลต่อการเรียนของคุณหรือไม่": "ปัญหา"}, inplace=True)
df.rename(columns={"1. คุณมีโรคประจำตัวหรือไม่": "โรค"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [1. ฉันรู้สึกเครียดเกี่ยวกับการเรียนอยู่บ่อยครั้ง]": "กังวลกับการเรียน"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [2. ฉันมีความกังวลเกี่ยวกับการเรียนไม่จบตามแผน]": "กังวลการเรียนไม่จบ"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [3. ฉันรู้สึกมั่นใจในความสามารถของตัวเองในการเรียนให้จบตามกำหนด]": "มั่นใจ"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [4. ฉันเคยรู้สึกหมดไฟ (burnout) ในการเรียน]": "หมดไฟ"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [5. ฉันสามารถรับมือกับแรงกดดันทางการเรียนได้ดี]": "แรงกดดัน"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [6. ฉันมีความสุขกับการเรียนในคณะนี้]": "ความสุข"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [7. ความเครียดจากเรื่องส่วนตัวส่งผลต่อการเรียนของฉัน]": "ความเครียด"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [8. ฉันรู้สึกโดดเดี่ยวหรือขาดการสนับสนุนทางจิตใจในระหว่างการเรียน]": "จิตใจ"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [9. ฉันมีปัญหาในการควบคุมอารมณ์เมื่อต้องเผชิญกับความล้มเหลวทางการเรียน]": "อารมณ์"}, inplace=True)
df.rename(columns={"โปรดให้คะแนนความคิดเห็นของคุณในแต่ละข้อโดยเลือกหนึ่งจาก 5 ตัวเลือกนี้ (โปรดเลือก 1 ตัวเลือก)\n1 = ไม่เห็นด้วยเลย\n2 = ไม่เห็นด้วย \n3 = เฉยๆ\n4 = เห็นด้วย \n5 = เห็นด้วยมาก  [10. ฉันรู้สึกว่าตัวเองมีคุณค่าและมีเป้าหมายชัดเจนในการเรียน]": "เป้าหมาย"}, inplace=True)
df.rename(columns={"1.  ปัจจัยใดที่ท่านคิดว่ามีผลมากที่สุดต่อการจบการศึกษาตามกำหนดของท่าน  ": "เหตุผลปลายเปิด"}, inplace=True)
df.rename(columns={"2.  มีสิ่งใดที่ท่านอยากให้มหาวิทยาลัยปรับปรุงเพื่อสนับสนุนการเรียนให้จบตรงตามกำหนด  ": "มหาลัย"}, inplace=True)
df.rename(columns={"3.  ข้อเสนอแนะเพิ่มเติม (ถ้ามี)  ": "อื่นๆ"}, inplace=True)
df.rename(columns={"คุณคิดว่าคุณจะสามารถจบการศึกษาได้ตามกำหนดเวลาหรือไม่? ": "สรุป"}, inplace=True)

worksheet.update([df.columns.values.tolist()] + df.values.tolist())

df['Gpax'] = df['GPAX'] = pd.to_numeric(df['GPAX'], errors='coerce')  # ป้องกัน Error หากว่ามีค่า Nan ในคอลัมน์ GPAX
df['จบตามแผน_กราฟ'] = df['จบตามแผน'] #เอาไปใช้ในกราฟ

#เอาคอลัมน์ที่ไม่เกี่ยวข้องออก
df = df.drop(columns=['Time', 'Policy'])

#แปลงเกรดให้เป็นเกณฑ์
def map_gpax(gpax):
    if gpax >= 3.50:
        return 3
    elif gpax >= 3.00:
        return 2
    elif gpax >= 2.50:
        return 1
    else:
        return 0
    
#แปลงคำตอบของแต่ละคำถามให้เป็นเกณฑ์คะแนน
df['GPAX'] = df['GPAX'].apply(map_gpax)
df["ถอน"] = df["ถอน"].map({"เคย (ตอบคำถามข้อถัดไป)": 0, "ไม่เคย(ข้ามไปตอบ ข้อ.5)": 1})
df["พักการเรียน"] = df["พักการเรียน"].map({"เคย": 0, "ไม่เคย": 1})
df["เข้าเรียน"] = df["เข้าเรียน"].map({"ฉันเข้าเรียนทุกครั้ง": 1, "ฉันเข้าเรียนเกือบทุกครั้ง": 1,"เข้าบ้างไม่เข้าบ้าง": 0,"ฉันเข้าเรียนบางครั้ง": 0,"ฉันไม่เคยเข้าเรียน": 0})
df["ส่งงาน"] = df["ส่งงาน"].map({"ฉันส่งงานครบ และตรงเวลาทุกครั้ง": 1, "ฉันส่งงานครบ แต่ส่งเลทบางครั้ง": 1,"ฉันส่งงานบางครั้ง": 0,"ฉันไม่ค่อยส่งงาน": 0,"ฉันไม่ส่งงานเลย": 0})
df["F"] = df["F"].map({"เคย": 0, "ไม่เคย": 1})
df["จบตามแผน"] = df["จบตามแผน"].map({"ใช่": 1, "ไม่ใช่": 0})
df["ครอบครัว"] = df["ครอบครัว"].map({"ใช่": 0, "ไม่ใช่": 1})
df["สรุป"] = df["สรุป"].map({"แน่ใจว่าจบ": 1, "น่าจะได้": 1, "ยังไม่แน่ใจ": 0, "น่าจะไม่ได้": 0, "ไม่น่าจะได้แน่นอน": 0})
df['พาร์ทไทม์'] = df['พาร์ทไทม์'].map({'ใช่ ฉันทำงานประจำ (ตอบคำถามข้อถัดไป)': 0, 'ใช่ ฉันทำงานพาร์ทไทม์(ตอบคำถามข้อถัดไป)': 0, 'ไม่ ฉันไม่ได้ทำงาน': 1})

# เลือกคุณลักษณะที่เกี่ยวข้องมากขึ้น
features = ["GPAX", "ถอน", "พักการเรียน", "เข้าเรียน", "ส่งงาน", "F", "ครอบครัว","พาร์ทไทม์"]
x = df[features]
y = df["สรุป"]

imputer = SimpleImputer(strategy="most_frequent")  # เติมค่าที่หายไปด้วยค่าที่พบบ่อยที่สุด
X_imputed = imputer.fit_transform(x)

# ปรับขนาดข้อมูล
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X_imputed)

# แบ่งข้อมูลออกเป็นชุดฝึกและชุดทดสอบ
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# จัดการกับข้อมูลที่ไม่สมดุล (SMOTE)
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X_train, y_train)

X_res = pd.DataFrame(X_res, columns=x.columns)
X_test_df = pd.DataFrame(X_test, columns=x.columns)

# สร้างและฝึกโมเดล
model = HistGradientBoostingClassifier(random_state=42)
model.fit(X_res, y_res)

# ทำนายผล
y_pred = model.predict(X_test_df)  # ทำนายด้วย DataFrame ที่มีชื่อฟีเจอร์เหมือนกัน
y_proba = model.predict_proba(X_test_df)[:, 1]  # ทำนายความน่าจะเป็น

# ประเมินผล
accuracy = accuracy_score(y_test, y_pred)
conf_mat = confusion_matrix(y_test, y_pred)
report = classification_report(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_proba)

#ดูจำนวนข้อมูลว่าก่อนและหลังปรับข้อมูลมีเท่าไหร่
print("Original Train dataset shape:", pd.Series(y).value_counts())
print("Resampled Train dataset shape:", pd.Series(y_res).value_counts())

#แสดงผลลัพธ์ว่าโมเดลสามารถแยกแยะคลาสได้ดีขนาดไหน
print("ROC AUC:", roc_auc)

#แสดงผลลัพธ์ความแม่นยำ
print("Accuracy:", accuracy)

#แสดงผลการทำนาย
print("Predictions:", y_pred)

#ตาราง Confusion Matrix
print("Confusion Matrix:")
print(conf_mat)

#Classification Report
print("Classification Report:")
print(report)

# หากต้องการแสดงผลการทำนายพร้อมกับค่าจริง (True labels) ของข้อมูลทดสอบ
print("True values:", y_test.values)

#ตรวจสอบจำนวนข้อมูลทีเอามาเทรน
print(f"Total data: {len(x)}")
print(f"Train set: {len(X_train)}, Test set: {len(X_test)}")

#ทดสอบความแม่นยำ
cross_val_scores = cross_val_score(model, X_train, y_train, cv=5)
print(f"Cross-validation scores: {cross_val_scores}")
#ค่ากลางของความแม่นยำ
print(f"Mean cross-validation score: {cross_val_scores.mean()}")

#กราฟที่ 1: ตาราง Confusion Matrix 
plt.figure(figsize=(6, 5))
sns.heatmap(conf_mat, annot=True, fmt="d", cmap="Blues", xticklabels=["ไม่จบ", "จบตามแผน"], yticklabels=["ไม่จบ", "จบตามแผน"])
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()

#กราฟที่ 2: กราฟแท่งแสดงการว่าเกรดสัมพันธ์กับโอกาสจบเท่าไหร่
plt.figure(figsize=(8, 6))
sns.histplot(df[df['สรุป'] == 1]['Gpax'], kde=True, color='blue', label='คิดว่าตัวเองมีโอกาสที่จะจบตามแผน', stat="density")
sns.histplot(df[df['สรุป'] == 0]['Gpax'], kde=True, color='red', label='คิดว่าตัวเองมีโอกาสที่จะไม่จบตามแผน', stat="density")
plt.xlabel('GPAX')
plt.ylabel('ความหนาแน่น')
plt.title('การกระจายของตัวของ GPAX กับความมั่นใจว่าตัวเองจะมีโอกาสจบตามแผน ')
plt.legend()
plt.show()

#กราที่ 3: การสร้าง heatmap เพื่อดูความสัมพันธ์ระหว่างคุณลักษณะต่างๆ กับผลการเรียน (เช่น GPAX, การเข้าเรียน, การส่งงาน) ซึ่งสามารถแสดงให้เห็นว่าคุณลักษณะใดมีความสัมพันธ์สูงกับการจบการศึกษาตามแผน
plt.figure(figsize=(8, 6))
corr_matrix = df[features].corr()
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)
plt.title('Heatmap ความสัมพันธ์ของตัวแปรต่างๆ กับการจบการศึกษาตามแผน')
plt.show()

# กราฟที่ 4: เหตุผลที่อาจทำให้นักศึกษาไม่จบการศึกษาตามแผน
reason_counts = Counter(df['เหตุผล'].str.split(', ').explode())
reason_df = pd.DataFrame(list(reason_counts.items()), columns=["เหตุผล", "จำนวนครั้ง"])

plt.figure(figsize=(12, 8))
reason_df = reason_df.sort_values(by="จำนวนครั้ง", ascending=False)
plt.barh(reason_df["เหตุผล"], reason_df["จำนวนครั้ง"], color="navy")
plt.xlabel("จำนวนครั้งที่เลือก")
plt.ylabel("เหตุผล")
plt.title("เหตุผลที่อาจทำให้นักศึกษาไม่จบการศึกษาตามแผน")
plt.tight_layout()
plt.show()

# กราฟที่ 5: ระดับความกังวลเกี่ยวกับการเรียนไม่จบตามแผน
plt.figure(figsize=(10, 6))
df['กังวลการเรียนไม่จบ'].value_counts().plot(kind='bar', color='salmon')
plt.title("ระดับความกังวลเกี่ยวกับการเรียนไม่จบตามแผน")
plt.xlabel("ระดับความกังวล")
plt.ylabel("จำนวนผู้ตอบ")
plt.show()

# กราฟที่ 6: นักศึกษาที่สามารถดู Degree Plan ได้
plt.figure(figsize=(10, 6))
df['ดู Degree'].value_counts().plot(kind='bar', color='cyan')
plt.title("จำนวนนักศึกษาที่ดู Degree Plan เป็น")
plt.xlabel("ดู Degree Plan เป็นไหม")
plt.ylabel("จำนวนผู้ตอบ")
plt.show()

# กราฟที่ 7: กราฟความกังวลกับเหตุผลที่อาจทำให้นักศึกษาไม่จบการศึกษาตามแผน
df_concern = df[['กังวลการเรียนไม่จบ', 'เหตุผล']].dropna()

# แยกแต่ละเหตุผลออกมาเป็นแถว
df_exploded = df_concern.assign(
    เหตุผล=df_concern['เหตุผล'].str.split(', ')
).explode('เหตุผล')

# นับจำนวนเหตุผลตามระดับความกังวล
concern_reason_counts = df_exploded.groupby(
    ['กังวลการเรียนไม่จบ', 'เหตุผล']
).size().unstack(fill_value=0)

# สร้างกราฟ stacked bar chart
fig, ax = plt.subplots(figsize=(10, 6))  # สร้าง Figure และ Axes พร้อมกัน
concern_reason_counts.plot(
    kind='bar',
    stacked=True,
    colormap='Paired',
    ax=ax  # ระบุให้ plot ลงในกราฟนี้
)
plt.title("ความกังวลเกี่ยวกับการเรียนไม่จบตามแผนกับเหตุผล")
plt.xlabel("ระดับความกังวลเกี่ยวกับการเรียนไม่จบ")
plt.ylabel("จำนวนครั้งที่เลือกเหตุผล")
plt.xticks(rotation=0)
plt.legend(title='เหตุผล', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

# ฟังก์ชันรับ input จากผู้ใช้
def get_user_input():
    try:
        in_gpax = float(input("กรุณากรอก GPAX: "))
        gpax = map_gpax(in_gpax)
        withdrawn = int(input("เคยถอนวิชาไหม? (0 = เคย, 1 = ไม่เคย): "))
        leave_study = int(input("เคยพักการเรียนไหม? (0 = เคย, 1 = ไม่เคย): "))
        attend_class = int(input("เข้าเรียนสม่ำเสมอไหม? (1 = สม่ำเสมอ, 0 = ไม่สม่ำเสมอ): "))
        submit_homework = int(input("ส่งงานตรงเวลาไหม? (1 = ตรงเวลา, 0 = ไม่ค่อยส่ง): "))
        f_grade = int(input("เคยได้ F ไหม? (0 = เคย, 1 = ไม่เคย): "))
        family_problem = int(input("มีปัญหาครอบครัวไหม? (1 = ไม่มีปัญหา, 0 = มีปัญหา): "))
        part_time = int(input("ทำงานพาร์ทไทม์ หรือ งานประจำไหม? (1 = ไม่, 0 = ใช่): "))
        
        # ทำเป็น DataFrame หนึ่งแถวสำหรับนำไปพยากรณ์
        user_input = pd.DataFrame([{
            "GPAX": gpax * 1.5,  # ถ่วงน้ำหนัก GPAX เช่นเดียวกับข้อมูลตอนฝึก
            "ถอน": withdrawn * 1.5,
            "พักการเรียน": leave_study * 1.2,
            "เข้าเรียน": attend_class * 1.0,
            "ส่งงาน": submit_homework * 1.0,
            "F": f_grade * 1.5,
            "ครอบครัว": family_problem * 0.5,
            "พาร์ทไทม์": part_time * 0.5
        }])
        
        return user_input
    
    except Exception as e:
        print(f"เกิดข้อผิดพลาด: {e}")
        return None

# ใช้งานฟังก์ชันรับ input แล้วทำนาย
user_input = get_user_input()

if user_input is not None:
    prediction = model.predict(user_input)
    if prediction[0] == 1:
        print("✅ คุณมีแนวโน้มจะจบการศึกษาตามกำหนด!")
    else:
        print("⚠️ คุณอาจมีความเสี่ยงที่จะไม่จบการศึกษาตามกำหนด") 